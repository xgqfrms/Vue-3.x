const { createApp } = require('vue');
import App from "./App.vue";

createApp(App).mount("#app");
